// Static copy of resources/js/app.js + bootstrap/ui
import './bootstrap.js';
import './ui.js';

// Minimal CommonJS-friendly exports (none needed)