<div class="bottom-page">
    <div class="body-text">Điểm danh sinh viên bằng hình ảnh</div>
</div>